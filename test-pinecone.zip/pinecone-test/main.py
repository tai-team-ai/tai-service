from loguru import logger
logger.info("Importing libraries")
import pinecone
from fastapi import FastAPI


def create_app():
    logger.info("Creating app")
    app = FastAPI()
    logger.info("App created")
    return app
