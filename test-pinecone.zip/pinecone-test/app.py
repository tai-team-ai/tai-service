from aws_cdk import (
    aws_lambda as _lambda,
    App,
    aws_ec2 as ec2,
    Stack,
    Environment,
    Duration,
)
from constructs import Construct

app: App = App()

env = Environment(account="ACCOUNT_NUMBER", region="REGION")

class TestStack(Stack):

    def __init__(self, scope: Construct, id_: str, **kwargs) -> None:
        super().__init__(scope, id_, **kwargs)
        vpc = ec2.Vpc(
            scope=self,
            id="pinecone-test-vpc",
            vpc_name="pinecone-test-vpc",
            max_azs=1,
            nat_gateways=1,
            subnet_configuration=[
                ec2.SubnetConfiguration(
                    name="public",
                    subnet_type=ec2.SubnetType.PUBLIC,
                    cidr_mask=24,
                ),
                ec2.SubnetConfiguration(
                    name="private",
                    subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS,
                    cidr_mask=24,
                )
            ]

        )
        

        func: _lambda.DockerImageFunction = _lambda.DockerImageFunction(
            scope=self,
            id="pinecone-test-pbulic-subnet",
            function_name="pinecone-test-pbulic-subnet",
            tracing=_lambda.Tracing.ACTIVE,
            code=_lambda.DockerImageCode.from_image_asset("."),
            allow_public_subnet=True,
            vpc=vpc,
            vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PUBLIC),
            timeout=Duration.seconds(90),
        )
        func.add_function_url(
            auth_type=_lambda.FunctionUrlAuthType.NONE,
            cors=_lambda.FunctionUrlCorsOptions(
                allowed_headers=["*"],
                allowed_origins=["*"],
            ),
            invoke_mode=_lambda.InvokeMode.BUFFERED,
        )
        func_2: _lambda.DockerImageFunction = _lambda.DockerImageFunction(
            scope=self,
            id="pinecone-test-private-internet",
            function_name="pinecone-test-private-internet",
            tracing=_lambda.Tracing.ACTIVE,
            code=_lambda.DockerImageCode.from_image_asset("."),
            allow_public_subnet=True,
            vpc=vpc,
            vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS),
            timeout=Duration.seconds(90),
        )
        func_2.add_function_url(
            auth_type=_lambda.FunctionUrlAuthType.NONE,
            cors=_lambda.FunctionUrlCorsOptions(
                allowed_headers=["*"],
                allowed_origins=["*"],
            ),
            invoke_mode=_lambda.InvokeMode.BUFFERED,
        )
            

stack = TestStack(app, "pinecone-test", env=env)

app.synth()
